import React from 'react';

const MainContent = () => {
    return (
        <main style={{ padding: '15px',  color: '#3a5bc6', textAlign: 'center'  }}>
            <h2>Bem-vindo ao FaqGPT Gamer!</h2>
            <p>Aqui você pode tirar suas duvidas sobre o mundo gamer!</p>
        </main>
    );
};

export default MainContent;